
import React from 'react';

export default function Home() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white py-10 px-4 sm:px-10">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-4 text-neon">NeonBazaar</h1>
        <p className="text-center text-zinc-400 mb-6">Web3 Retro Economic Simulation Game</p>

        <div className="bg-zinc-900 border border-zinc-700 rounded p-6 mb-8">
          <h2 className="text-2xl font-semibold mb-2">🌍 Select Your Region</h2>
          <select className="w-full bg-zinc-800 border border-zinc-700 p-2 rounded text-white">
            <option>Taiwan</option>
            <option>Philippines</option>
            <option>Vietnam</option>
            <option>India</option>
          </select>
        </div>

        <div className="bg-zinc-900 border border-zinc-700 rounded p-6 mb-8">
          <h2 className="text-2xl font-semibold mb-2">🧙‍♂️ Choose Your Role</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <button className="bg-zinc-800 p-4 rounded">👨‍🍳 Merchant</button>
            <button className="bg-zinc-800 p-4 rounded">🚴 Delivery</button>
            <button className="bg-zinc-800 p-4 rounded">🛍 Consumer</button>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-700 rounded p-6">
          <h2 className="text-2xl font-semibold mb-2">🎮 Demo Mode</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
            <div className="bg-zinc-800 p-4 rounded">
              <p className="text-xl font-bold">YNS Points</p>
              <p className="text-sm text-zinc-400">Earnable via missions and purchases.</p>
            </div>
            <div className="bg-zinc-800 p-4 rounded">
              <p className="text-xl font-bold">DAO Proposals</p>
              <p className="text-sm text-zinc-400">Vote and fund your favorite shops.</p>
            </div>
            <div className="bg-zinc-800 p-4 rounded">
              <p className="text-xl font-bold">NFT Certificates</p>
              <p className="text-sm text-zinc-400">Upgradeable role-based proof-of-identity.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
